<?php


session_start();
$server = "localhost";
$username = "root";
$password = "";
$db = "vaimchatuser";
$email = $_POST['em'];
$pass = $_POST['pw'];


$conn = mysqli_connect($server,$username,$password,$db);
$query = "SELECT * FROM users WHERE email='$email' AND pass='$pass'";
$result = mysqli_query($conn, $query);
$count = mysqli_num_rows($result);
if($count != 0){
    $_SESSION['em'] = $email;
    header("location: ../welcome.php");   
}

else{
    echo "<script language='javascript'>";
    echo "alert('User not Esixt')";
    echo "</script>"; 
}


?>