<?php



session_start();
$server = "localhost";
$username = "root";
$password = "";
$db = "vaimchatuser";
$room = $_POST['roomname'];







if(!isset($_SESSION['em'])){


    echo "<script language='javascript'>";
    echo "alert('User must be login first')";
    echo "</script>";
    header("location: ../login.php");

    


}




else if(strlen($room)>10 or strlen($room)<4){
    echo "<script language='javascript'>";
    echo "alert('Invailed room name')";
    echo "</script>";   
}

else if(!ctype_alnum($room)){
    echo "<script language='javascript'>";
    echo "alert('Roomname must in the form of alphanumeric')";
    echo "</script>";    
}




if(isset($_POST['join'])){
    $conn = mysqli_connect($server,$username,$password,$db);
    $query = "SELECT * FROM roomname WHERE roomnm='$room'";
    $result = mysqli_query($conn, $query);
    $count = mysqli_num_rows($result);
    if($count != 0){
        $_SESSION['re'] = $room;
           
        echo "<script language='javascript'>";
        echo "alert('Chatroom ready')";
        echo "</script>"; 
        header("location: ../rooms.php");       
  
    }

    else{
        echo "<script language='javascript'>";
        echo "alert('Room not Esixt')";
        echo "</script>"; 
    }
}



else{
    $conn = mysqli_connect($server,$username,$password,$db);
    $query = "SELECT * FROM roomname WHERE roomnm='$room'";
    $result = mysqli_query($conn, $query);
    $count = mysqli_num_rows($result);
    if($count != 0){
       
        echo "<script language='javascript'>";
        echo "alert('Room already Esixt')";
        echo "</script>";   
    }

    else{
        $addroom = "INSERT INTO `roomname` (`roomnm`, `stime`) VALUES ('$room', NOW());";
        if($add = mysqli_query($conn, $addroom)){


            $_SESSION['re'] = $room;
           
            echo "<script language='javascript'>";
            echo "alert('Chatroom ready')";
            echo "</script>"; 
            header("location: ../rooms.php");

        }

        else{
           
            echo "<script language='javascript'>";
            echo "alert('Chatroom cannot create')";
            echo "</script>"; 
            
        }
    }

}



?>
