<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "vaimchatuser";
$email = $_POST['em2'];
$pass = $_POST['pw2'];
$pass2 = $_POST['pw22'];


if($pass!=$pass2){


    echo "<script language='javascript'>";
    echo "alert('Password and Confirm password must be same')";
    echo "window.location.href = 'http://localhost/signup.php';";
    echo "</script>";
    header("location: ../signup.php");

    


}



else{
    $conn = mysqli_connect($server,$username,$password,$db);
    $query = "SELECT * FROM users WHERE email='$email' AND pass='$pass'";
    $result = mysqli_query($conn, $query);
    $count = mysqli_num_rows($result);
    if($count != 0){
        echo "<script language='javascript'>";
        echo "alert('User already Esixt')";
        echo "</script>";   
    }

    else{
        $adduser = "INSERT INTO users VALUES ( '$email', '$pass' )";
        if($add = mysqli_query($conn, $adduser)){
            echo "<script language='javascript'>";
            echo "alert('User ready')";
            echo "</script>"; 
        }

        else{
            echo "<script language='javascript'>";
            echo "alert('User cannot create')";
            echo "</script>"; 
        }
    }

}



?>
