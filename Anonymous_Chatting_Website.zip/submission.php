<?php
 
/*
* Write your logic to manage the data
* like storing data in database
*/
 
// POST Data



session_start();
$server = "localhost";
$username = "root";
$password = "";
$db = "vaimchatuser";
$msg =  $_POST['message'];
$ip  = $_SERVER['REMOTE_ADDR'];
$roomx = $_SESSION['re'];
$conn = mysqli_connect($server,$username,$password,$db);
$query = "INSERT INTO `messages_db` VALUES(  '$msg', '$roomx', NOW(), '$ip'  );";
mysqli_query($conn, $query);
mysqli_close($conn);
 


?>