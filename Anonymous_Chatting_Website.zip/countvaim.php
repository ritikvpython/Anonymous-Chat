<?php
 

session_start();
$server = "localhost";
$username = "root";
$password = "";
$db = "vaimchatuser";
$roomx = $_SESSION['re'];
$userx = $_SESSION['em'];
$conn = mysqli_connect($server,$username,$password,$db);
$query = "SELECT msg, xtime, ip FROM messages_db WHERE room='$roomx';";
$result = mysqli_query($conn, $query);

$usery = substr($userx, 0, strpos($userx, "@"));

if(mysqli_num_rows($result)){

    while($row = mysqli_fetch_assoc($result)){
        $vaim = $vaim . '<div class="darker">';
        $vaim = $vaim . $row['ip'] . '';
        $vaim = $vaim . '<p>' . $row['msg'] . '</p>';
        $vaim = $vaim . ' <span class="time-right">' . $row['xtime'] . '</span>';
        $vaim = $vaim . '</div>';
    }


}

echo $vaim;

mysqli_close($conn);
 


?>