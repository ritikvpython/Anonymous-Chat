<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Vaim-Chat | Sign in</title>
    <link rel="stylesheet" href="css/style3.css">

<style>
body {
  margin: 0;
  padding: 0;
  height: 100vh;
  background: url(bg.jpg) no-repeat center center fixed;
}

#particles-js {
  height: 100%;
  background: #262626;
}

</style>


  </head>
  <body>
    <div id="particles-js">

    </div>
    <script type="text/javascript" src="js/particles.js"></script>

    <script type="text/javascript" src="js/app.js"></script>

      <!--video src="#" muted loop autoplay></video-->

<form class="box" action="vaim.php" method="post">
  <h1>Login</h1>
  <input type="text" name="user" placeholder="Username">
  <input type="password" name="pass" placeholder="Password">
  <input type="submit" name="sub" value="Login">
</form>


  </body>
</html>
