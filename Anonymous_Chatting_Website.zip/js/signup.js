
function validateForm() {
  var x = document.forms["myForm"]["em2"].value;
  var y = document.forms["myForm"]["pw2"].value;
  var z = document.forms["myForm"]["pw22"].value;
  if (x == "") {
    alert("Email must be filled out");
    return false;
  }
  if (y == "") {
    alert("Password must be filled out");
    return false;
  }
  if (z == "") {
    alert("Confirm password must be filled out");
    return false;
  }



  else if(document.forms["myForm"]["pw2"].value.length <6){
	alert("Password too short !!");
	return false;
}
 else if(document.forms["myForm"]["pw2"].value.length >= 17){
	alert("Password is too long !!");
	return false;


}

}
