
function validateForm() {
    var x = document.forms["myForm"]["em"].value;
    var y = document.forms["myForm"]["pw"].value;
    if (x == "") {
      alert("Email must be filled out");
      return false;
    }
    if (y == "") {
      alert("Password must be filled out");
      return false;
    }  
    else if(document.forms["myForm"]["pw"].value.length <6){
      alert("Password too short !!");
      return false;
  }
   else if(document.forms["myForm"]["pw"].value.length >= 17){
      alert("Password is too long !!");
      return false;
  
  
  }
  
  }
  