
let vaim = document.getElementById("vaimpo");
vaim.addEventListener("click", vaimpier);



function vaimpier() {

    window.location = "signup.php";


}